from flask import Blueprint, render_template, request
from app.models.post import Post
from app.forms.post_forms import SearchForm

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
@main_bp.route('/home')
def home():
    page = request.args.get('page', 1, type=int)
    posts = Post.query.order_by(Post.created_at.desc()).paginate(page=page, per_page=5)
    return render_template('home.html', posts=posts)

@main_bp.route('/about')
def about():
    return render_template('about.html', title='About')

@main_bp.route('/search', methods=['GET', 'POST'])
def search():
    form = SearchForm()
    results = []
    
    if form.validate_on_submit() or request.args.get('search_query'):
        search_query = form.search_query.data if form.validate_on_submit() else request.args.get('search_query')
        results = Post.query.filter(
            (Post.title.contains(search_query)) | 
            (Post.content.contains(search_query))
        ).order_by(Post.created_at.desc()).all()
    
    return render_template('search.html', title='Search', form=form, results=results)

@main_bp.route('/announcements', methods=['GET', 'POST'])
def announcements():
    return render_template('announcements.html', title='Announcements')

@main_bp.route('/categories', methods=['GET', 'POST'])
def categories():
    return render_template('categories.html', title='Categories')

@main_bp.route('/contact', methods=['GET', 'POST'])
def contact():
    return render_template('contact.html', title='Contact')